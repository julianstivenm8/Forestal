import React, {Component} from 'react'
import {  StyleSheet, Text, View ,Image, TextInput,StatusBar,TouchableOpacity,Dimensions,ScrollView ,TouchableHighlight,ProgressBarAndroid  } from 'react-native';
import { StackNavigator } from 'react-navigation';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Constants} from 'expo';
//La  carpeta fue copiada directamente al node_modules, porque no me cargaba en el npm
import * as Progress from 'react-native-progress-master';

const { width, height } = Dimensions.get('window')

export default class protocolos extends Component {



/*  static navigationOptions = ({ navigation }) => {
    //  const {state, setParams} = navigation;
    //  const isInfo = state.params.mode === 'info';
    //  const {user} = state.params;

    const { navigate } = navigation;
      return {
       title: 'Protocolos activos',
        headerStyle: { marginTop: Constants.statusBarHeight },
       //headerTitleAllowFontScaling: 20,
        headerLeft: <MaterialCommunityIcons name="menu" size={32} color="#606060" />,
        headerRight:(
        <MaterialCommunityIcons    onPress={() => navigate('Chat',{user:'madrid'})} name="calendar-range" size={32} color="#606060" />
        ),
      };
  };*/
  //Del componente ScrollView
   state = {
        names: [
           {'name': 'Muestra de Botón de oro','porcentaje':3, 'id': 1},
           {'name': 'Muestra de Sinaí','porcentaje':50, 'id': 2}
        ]
     };
  //   var progressBar = require('ProgressBarAndroid');



  render() {


    const { navigate } = this.props.navigation;
    return(
      <View style={styles.container}>
        <StatusBar  hidden = {false} />
        <ScrollView>

              {
                 this.state.names.map((item,subItem, index) => (

               <TouchableOpacity key = {item.id}  style = {styles.item} onPress={() => navigate('PasoUno',{user:'PasoUno'})}>
            <View  style = {styles.itemTres}>
                      <View  style = {styles.itemDos}>
                        <Text style={styles.textGrayB} >{item.name}</Text>
                      </View>
                     <View style = {styles.itemEnd}>
                       <Text style={styles.textPorcentaje}>{item.porcentaje}%</Text>
                     </View>
                        </View>
                        <View  style = {styles.progress}>
                       <Progress.Bar progress={item.porcentaje/100} width={320} height={5} unfilledColor={'#EAEAEA'} color={'#D8940F'} borderWidth={0.2} borderColor={'#EAEAEA'} borderRadius={2}  />
                         </View>
                    </TouchableOpacity>

                 ))
              }
            <View  style = {styles.scrool}>
              <TouchableHighlight>
                <Text style={styles.buttonText} onPress={() => navigate('Muestra',{user:'Muestra'})}>Enviar protocolos</Text>
              </TouchableHighlight>
              <TouchableHighlight>
                <Text style={styles.buttonText} onPress={() => navigate('Muestra',{user:'Muestra'})}>Ver resultantes</Text>
              </TouchableHighlight>
              </View>

           </ScrollView>


        {/*
          <TouchableHighlight>
            <Text style={styles.buttonText} onPress={() => navigate('Index',{user:'Index'})}>Ver mis protocolos</Text>
          </TouchableHighlight>
           <View style={styles.slide}>
          <View style={styles.containerText}>
              <Text style={styles.textRed}>Administre sus predios</Text>
              <Text style={styles.textGray}>No dejes para mañana lo que puedes hacer hoy. Realiza todas las tareas que requiere su sistema silvopastoril.</Text>
              <Text style={styles.textGray}>!Alcance la mayor productividad¡</Text>
          </View>
        </View>*/}

          </View>

    )
  }
}
const styles = StyleSheet.create({
  wrapper: {
    backgroundColor: '#FFFFFF'
 },
 progress:{
   marginLeft:0 ,
 },
 buttonText:{
   fontSize:20,
   backgroundColor:'#A51414',
   color:'#ffff',
   //marginVertical:0,
   width:199,
   borderRadius:25,
   textAlign:'center',
   paddingVertical:9,
   marginBottom:20,
 },
 slide: {
   flex: 1,
   //backgroundColor: '#FFFFFF'
  alignItems: 'center',
   justifyContent: 'center',

   borderWidth: 1,
   borderRadius: 9,
   borderColor: '#ddd',
   borderBottomWidth: 0,
   shadowColor: '#000',
   shadowOffset: { width: 0, height: -1 },
   shadowOpacity: 4,
   shadowRadius: 9,
   elevation: 1,
   marginLeft:41 ,
   marginRight: 41,
   marginTop: 20,
   marginBottom: 67,

 },

 item: {
   flexDirection: 'column',
         justifyContent: 'space-between',
      //   alignItems: 'flex-start',
         padding: 17,
         margin: 5,
        // borderColor: '#2a4944',
        // borderWidth: 1,
        // backgroundColor: '#d2f7f1'

   flex: 1,
   //backgroundColor: '#FFFFFF'
  //alignItems: 'center',
  // justifyContent: 'center',

   borderWidth: 1,
   borderRadius: 9,
   borderColor: '#ddd',
   borderBottomWidth: 0,
   shadowColor: '#000',
   shadowOffset: { width: 0, height: -1 },
   shadowOpacity: 4,
   shadowRadius: 9,
   elevation: 1,
   //marginLeft:41 ,
   //marginRight: 41,
  // marginTop: 20,
   //marginBottom: 67,
 },
 itemDos: {

       },
itemTres: {
   flexDirection: 'row',
   justifyContent: 'space-between',
//   alignItems: 'center',
       },
 itemEnd: {

      },
 textPorcentaje: {
      fontSize:16,
  // paddingTop:1,
    },
 containerText: {
   flex: 2,
   backgroundColor:'#FFFFFF',
   alignItems: 'center',
   justifyContent: 'center',
   //paddingVertical:10,
   borderWidth:30,
   borderColor:'#FFFFFF',
 },
 textGrayB:{
   color:"#000000",
  //  fontFamily:'roboto-medium',
   fontSize:21,
   marginBottom:5,
//   textAlign: 'left'
 },
 textGray:{
   color:'#000000',
   //marginBottom:10,
   fontSize:15,
   textAlign: 'left'
 },
 container: {
   flex: 1,
    backgroundColor: '#FFFFFF'
 },
 imgBackground: {
   width,
   height,
   backgroundColor: 'transparent',
   position: 'absolute'
 },
 scrool: {
   alignItems: 'center',
   marginTop:33

 },
});
