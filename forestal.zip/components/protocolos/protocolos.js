import React, {Component} from 'react'
import {  StyleSheet, Text, View ,Image, TextInput,StatusBar,TouchableOpacity,Dimensions,ScrollView ,Button} from 'react-native';
import { StackNavigator, DrawerNavigator } from 'react-navigation';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Constants} from 'expo';

const { width, height } = Dimensions.get('window')



export default class protocolos extends Component {

/*  static navigationOptions = ({ navigation }) => {
      const {state, setParams,navigate} = navigation;
    //  const isInfo = state.params.mode === 'info';
    //  const {user} = state.params;

  //  const { navigate } = navigation;
      return {

       title: 'Protocolos activos',
         headerStyle: { marginTop: Constants.statusBarHeight },
        headerLeft: <MaterialCommunityIcons  onPress={() => navigate('DrawerOpen')} name="menu" size={32} color="#606060" />,
        headerRight:(
        <MaterialCommunityIcons    onPress={() => navigate('Chat',{user:'madrid'})} name="calendar-range" size={32} color="#606060" />
      ),
      drawerLabel:'protocolos'
      };
  };*/
  //Del componente ScrollView
   state = {
        names: [
           {'name': 'Protocolo para realizar aforos','subName':'Creado por CIPAV', 'id': 1}
        ]
     };

  render() {
    const { navigate } = this.props.navigation;
    return(

      <View style={styles.container}>

        <ScrollView>
              {
                 this.state.names.map((item,subItem, index) => (

               <TouchableOpacity key = {item.id}  style = {styles.item} onPress={() => navigate('Muestra',{user:'Muestra'})}>

                      <View  style = {styles.itemDos}>
                        <Text style={styles.textGrayB} >{item.name}</Text>
                        <Text style={styles.textGray}>{item.subName}</Text>
                      </View>
                     <View style = {styles.itemDos}>
                       <Text style={styles.textPorcentaje}>0%</Text>
                     </View>

                    </TouchableOpacity>

                 ))
              }
           </ScrollView>


        {/*
          <TouchableHighlight>
            <Text style={styles.buttonText} onPress={() => navigate('Index',{user:'Index'})}>Ver mis protocolos</Text>
          </TouchableHighlight>
           <View style={styles.slide}>
          <View style={styles.containerText}>
              <Text style={styles.textRed}>Administre sus predios</Text>
              <Text style={styles.textGray}>No dejes para mañana lo que puedes hacer hoy. Realiza todas las tareas que requiere su sistema silvopastoril.</Text>
              <Text style={styles.textGray}>!Alcance la mayor productividad¡</Text>
          </View>
        </View>*/}

          </View>

    )
  }
}


const styles = StyleSheet.create({
  wrapper: {
    backgroundColor: '#FFFFFF'
 },
 buttonText:{
   fontSize:20,
   //fontWeight:'500',
   backgroundColor:'#A51414',
   color:'#ffff',

   marginVertical:10,
   width:199,
   borderRadius:25,
   textAlign:'center',
   paddingVertical:9,
   marginBottom:27,
 },
 slide: {
   flex: 1,
   //backgroundColor: '#FFFFFF'
  alignItems: 'center',
   justifyContent: 'center',

   borderWidth: 1,
   borderRadius: 9,
   borderColor: '#ddd',
   borderBottomWidth: 0,
   shadowColor: '#000',
   shadowOffset: { width: 0, height: -1 },
   shadowOpacity: 4,
   shadowRadius: 9,
   elevation: 1,
   marginLeft:41 ,
   marginRight: 41,
   marginTop: 20,
   marginBottom: 67,

 },

 item: {
   flexDirection: 'row',
         justifyContent: 'space-between',
         alignItems: 'flex-start',
         padding: 17,

         margin: 5,
        // borderColor: '#2a4944',
        // borderWidth: 1,
        // backgroundColor: '#d2f7f1'

   flex: 1,
   //backgroundColor: '#FFFFFF'
  //alignItems: 'center',
  // justifyContent: 'center',

   borderWidth: 1,
   borderRadius: 9,
   borderColor: '#ddd',
   borderBottomWidth: 0,
   shadowColor: '#000',
   shadowOffset: { width: 0, height: -1 },
   shadowOpacity: 4,
   shadowRadius: 9,
   elevation: 1,
   //marginLeft:41 ,
   //marginRight: 41,
  // marginTop: 20,
   //marginBottom: 67,
 },
 itemDos: {
   flexDirection: 'column',
         justifyContent: 'space-between',
         alignItems: 'flex-start',
       },
 textPorcentaje: {
   fontSize:16,
         flexDirection: 'column',
               justifyContent: 'space-between',
               alignItems: 'flex-start',
               paddingTop:10,
             },
 containerText: {
   flex: 2,
   backgroundColor:'#FFFFFF',
   alignItems: 'center',
   justifyContent: 'center',
   //paddingVertical:10,
   borderWidth:30,
   borderColor:'#FFFFFF',
 },
 textGrayB:{
   color:"#000000",
  //  fontFamily:'roboto-medium',
   fontSize:21,
   marginBottom:5,
   textAlign: 'left'
 },
 textGray:{
   color:'#000000',
   //marginBottom:10,
   fontSize:15,
   textAlign: 'left'
 },
 container: {
   flex: 1,
    backgroundColor: '#FFFFFF'
 },
 imgBackground: {
   width,
   height,
   backgroundColor: 'transparent',
   position: 'absolute'
 },
 image: {
   width:276,
   height:276,
   alignItems: 'center',
   justifyContent: 'center',
    borderRadius:9,
 },
});
